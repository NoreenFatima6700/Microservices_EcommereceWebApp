from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample in-memory database (list of users)
users = []

# POST endpoint to create a new user
@app.route('/users', methods=['POST'])
def create_user():
    data = request.get_json()  # Get JSON data from the request
    user = {
        "name": data['name'],
        "email": data['email']
    }
    users.append(user)
    return jsonify({"message": "User created successfully!", "user": user}), 201

# GET endpoint to retrieve all users
@app.route('/users', methods=['GET'])
def get_users():
    return jsonify(users), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

from flask import Flask, request, jsonify

app = Flask(__name__)

# In-memory notifications database
notifications = []

# Route: Receive a notification
@app.route('/notifications', methods=['POST'])
def receive_notification():
    data = request.get_json()
    order_id = data.get('order_id')
    message = data.get('message')

    # Store the notification
    notification = {"order_id": order_id, "message": message}
    notifications.append(notification)

    return jsonify({"message": "Notification received!"}), 200

# Route: Get all notifications
@app.route('/notifications', methods=['GET'])
def get_notifications():
    return jsonify(notifications), 200

# Run the app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5004)

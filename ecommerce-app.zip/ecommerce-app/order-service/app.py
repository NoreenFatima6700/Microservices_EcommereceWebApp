from flask import Flask, request, jsonify
import requests  # To send HTTP requests to other services

app = Flask(__name__)

# In-memory orders database
orders = []

# Route: Place a new order
@app.route('/orders', methods=['POST'])
def place_order():
    data = request.get_json()
    product_id = data.get('product_id')

    # Step 1: Fetch product details from the Product Service
    try:
        product_service_url = f"http://localhost:5001/products/{product_id}"
        response = requests.get(product_service_url)
        response.raise_for_status()  # Raise an error for 4xx/5xx responses
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Product Service error: {str(e)}"}), 500

    if response.status_code == 200:
        product = response.json()

        # Step 2: Check if the product is in stock
        if product.get('stock', 0) > 0:
            # Step 3: Place the order
            orders.append(data)
            return jsonify({"message": "Order placed successfully!", "order": data}), 201
        else:
            return jsonify({"error": "Product out of stock!"}), 400
    else:
        return jsonify({"error": "Product not found!"}), 404

# Route: Get all orders
@app.route('/orders', methods=['GET'])
def get_orders():
    return jsonify(orders), 200

# Run the app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)

from flask import Flask, request, jsonify

app = Flask(__name__)

# In-memory product database (using a dictionary for unique IDs)
products = {}

# Route: Add a new product
@app.route('/products', methods=['POST'])
def add_product():
    data = request.get_json()

    # Validate product data
    if not data or 'product_id' not in data or 'name' not in data or 'stock' not in data:
        return jsonify({"error": "Invalid product data! Required fields: product_id, name, stock"}), 400

    product_id = data['product_id']

    # Check if the product already exists
    if product_id in products:
        return jsonify({"error": "Product with this ID already exists!"}), 400

    # Add the new product to the database
    products[product_id] = {
        "name": data['name'],
        "stock": data['stock']
    }

    return jsonify({"message": "Product added successfully!", "product": products[product_id]}), 201

# Route: Get all products
@app.route('/products', methods=['GET'])
def get_products():
    return jsonify(products), 200

# Route: Get product by ID
@app.route('/products/<int:product_id>', methods=['GET'])
def get_product_by_id(product_id):
    product = products.get(product_id)
    if product:
        return jsonify(product), 200
    else:
        return jsonify({"error": "Product not found!"}), 404

# Health check route
@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy"}), 200

# Run the app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)

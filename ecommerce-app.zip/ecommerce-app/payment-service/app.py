from flask import Flask, request, jsonify
import requests  # To send HTTP requests to other services

app = Flask(__name__)

# In-memory payments database
payments = []

# Route: Process a payment
@app.route('/payments', methods=['POST'])
def process_payment():
    data = request.get_json()
    order_id = data.get('order_id')
    amount = data.get('amount')

    # Process the payment (for now, just append it to the payments list)
    payment = {"order_id": order_id, "amount": amount}
    payments.append(payment)

    # Step 1: Notify the Notification Service
    notification_service_url = "http://notification-service:5004/notifications"
    notification_data = {
        "order_id": order_id,
        "message": f"Payment of ${amount} received for order #{order_id}"
    }
    
    try:
        response = requests.post(notification_service_url, json=notification_data)
        if response.status_code == 200:
            return jsonify({"message": "Payment processed and notification sent!"}), 201
        else:
            return jsonify({"error": "Payment processed but notification failed!"}), 500
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Failed to connect to Notification Service!"}), 500

# Route: Get all payments
@app.route('/payments', methods=['GET'])
def get_payments():
    return jsonify(payments), 200

# Run the app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5003)
